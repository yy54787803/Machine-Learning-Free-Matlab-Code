# Matlab-Machine
The download method of these codes.
![image](https://user-images.githubusercontent.com/110336517/219842738-ceef3809-f443-453d-a6c3-1c35fe73e27f.png)
